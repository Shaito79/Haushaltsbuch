<?php

$transaktionen = [

    [
        "datum" => "2026-07-01",
        "typ" => "Einnahme",
        "betrag" => 2500,
        "thema" => "Gehalt"
    ],

    [
        "datum" => "2026-07-05",
        "typ" => "Ausgabe",
        "betrag" => 700,
        "thema" => "Miete"
    ],

    [
        "datum" => "2026-07-10",
        "typ" => "Ausgabe",
        "betrag" => 150,
        "thema" => "Lebensmittel"
    ],

    [
        "datum" => "2026-07-15",
        "typ" => "Ausgabe",
        "betrag" => 80,
        "thema" => "Freizeit"
    ]

];